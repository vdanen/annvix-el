/* Public domain. */

#ifndef PROT_H
#define PROT_H

extern int prot_gid(int);
extern int prot_uid(int);

#endif
