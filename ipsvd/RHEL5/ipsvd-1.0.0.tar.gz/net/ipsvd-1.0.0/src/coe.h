/* Public domain. */

#ifndef COE_H
#define COE_H

extern int coe(int);

#endif
